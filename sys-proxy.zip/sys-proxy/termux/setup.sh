#!/data/data/com.termux/files/usr/bin/bash
# setup.sh - phone-only sys-proxy bootstrap for Termux (Android)
#
# Run this from inside the sys-proxy folder, after `pkg install git` and
# either copying this folder onto the phone or cloning it. No PC required
# at any point - this installs Node, deps, generates a CA, and starts the
# proxy entirely on-device.
#
# Usage:
#   chmod +x termux/setup.sh
#   ./termux/setup.sh

set -e

echo "=== sys-proxy Termux setup (phone-only, no PC) ==="
echo ""

# Termux note: only the F-Droid build of Termux works reliably for
# package installs - the Play Store build is outdated and frequently
# fails here. If `pkg` itself is broken/missing packages, that's why.

echo "[1/5] Updating Termux package index..."
pkg update -y >/dev/null 2>&1 || { echo "pkg update failed - if this hangs, run 'termux-change-repo' to pick a closer mirror, then retry."; exit 1; }

echo "[2/5] Installing Node.js (LTS)..."
pkg install -y nodejs-lts >/dev/null 2>&1 || pkg install -y nodejs

node --version
npm --version

echo "[3/5] Requesting Termux:API wake-lock + storage perms (optional, for staying alive in background)..."
pkg install -y termux-api >/dev/null 2>&1 || echo "  (termux-api not available - skipping, not required)"

echo "[4/5] Installing sys-proxy dependencies..."
cd "$(dirname "$0")/.."
npm install --no-audit --no-fund

echo "[5/5] Generating local CA (only if one doesn't already exist)..."
npm run gen-ca

echo ""
echo "=== Setup complete ==="
echo ""

# The IP that matters here is the phone's own Wi-Fi IP, since the proxy
# setting you configure under Settings -> Wi-Fi -> Modify network ->
# Proxy needs to point at the device the proxy server is actually
# running on - which, in this setup, is this same phone.
PHONE_IP=$(ip route get 1.1.1.1 2>/dev/null | grep -oP 'src \K\S+' || echo "<run 'ip addr' to find your Wi-Fi IP>")

echo "Your phone's Wi-Fi IP appears to be: $PHONE_IP"
echo ""
echo "Next steps:"
echo "  1. Start the proxy: npm start  (or: termux/keep-alive.sh for background)"
echo "  2. Install the CA on THIS phone: open a browser and go to"
echo "     http://127.0.0.1:8889/ca  -- then follow the Android install"
echo "     instructions (Settings -> Security -> Install a certificate)."
echo "  3. Set Wi-Fi proxy: Settings -> Wi-Fi -> long-press your network ->"
echo "     Modify network -> Advanced -> Proxy -> Manual."
echo "     Server: $PHONE_IP   Port: 8888"
echo "  4. Open hook.html (in any browser, including this phone's) and"
echo "     connect to ws://$PHONE_IP:8889 under the MITM Proxy Link settings."
echo ""
echo "Note: Android only trusts user-installed CAs for the browser by"
echo "default since Android 7+ - apps with their own network security"
echo "config may ignore it unless they opt in. This is an Android"
echo "platform restriction, not specific to this tool."
