#!/data/data/com.termux/files/usr/bin/bash
# keep-alive.sh - run sys-proxy in the background with a wake-lock so
# Android is less likely to kill it when Termux isn't in the foreground.
#
# This is NOT bulletproof. Android (especially OEM skins like MIUI, EMUI,
# OneUI) can still kill background processes despite a wake-lock, via
# their own battery managers or the "Phantom Process Killer" on Android
# 12/13. If the proxy keeps dying, also do, manually:
#   - Termux app info -> Battery -> Unrestricted (not just "not optimized")
#   - Your phone's separate battery/power-saving manager -> add Termux to
#     the "never sleep" / "no restrictions" list (varies by manufacturer)
#   - Disable battery saver mode entirely while using this
#
# Usage:
#   pkg install tmux        (once)
#   chmod +x termux/keep-alive.sh
#   ./termux/keep-alive.sh

set -e
cd "$(dirname "$0")/.."

if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux not found - installing..."
  pkg install -y tmux
fi

if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock
  echo "Wake-lock acquired (prevents CPU sleep while Termux is open)."
else
  echo "termux-wake-lock not found - install termux-api package and the"
  echo "Termux:API app from F-Droid for this to work: pkg install termux-api"
fi

SESSION=sysproxy
if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "Session '$SESSION' already running. Reattaching..."
else
  echo "Starting sys-proxy in tmux session '$SESSION'..."
  tmux new -d -s "$SESSION" "node src/server.js"
fi

echo ""
echo "Running in background. To view logs: tmux attach -t $SESSION"
echo "To detach without stopping: press Ctrl+B then D"
echo "To stop entirely: tmux kill-session -t $SESSION"
