# sys-proxy

A real local MITM (man-in-the-middle) proxy backend for `px://hook`. Unlike
the old `corsproxy.io`-based "Browser" tab — which ran entirely inside a
sandboxed `fetch()` call and could never see real `Sec-Fetch-*`, real
`User-Agent`, real `Accept-Encoding`, or non-GET navigations properly —
this sits on the actual network path the way Burp Suite / mitmproxy /
Charles do. Your phone or desktop sends traffic *to this proxy*, it
forwards it to the real destination, and it shows you exactly what went
over the wire, including decrypted HTTPS.

## How it works

- A root CA certificate is generated once, locally. You install it as a
  trusted root on whichever devices you want to intercept.
- The proxy listens for plain HTTP proxy requests **and** `CONNECT`
  tunnels. For HTTPS, it terminates TLS itself using a certificate it
  mints on the fly for whatever hostname the client is connecting to,
  signed by your CA — so the client trusts it, and the proxy can read
  the decrypted traffic in both directions before re-encrypting and
  forwarding it upstream over real HTTPS.
- Every request/response (any method — GET, POST, PUT, PATCH, DELETE,
  whatever) is captured in full: headers, body, status, timing.
- Captures are pushed live over WebSocket and kept in a short in-memory
  history, so `px://hook`'s UI can connect and show real traffic.

This is the same trust model every interception proxy uses. The CA key
never leaves your machine, and only traffic from devices you've
explicitly pointed at this proxy (and that trust your CA) is visible.

## Setup

```bash
cd sys-proxy
npm install
npm run gen-ca       # generates certs/ca.key.pem + certs/ca.cert.pem (once)
npm start             # starts the proxy (port 8888) + API/WebSocket (port 8889)
```

You'll see:
```
[sys-proxy] MITM proxy listening on 0.0.0.0:8888
[sys-proxy] API + WebSocket on 0.0.0.0:8889
[sys-proxy] Install CA cert from: http://<this-host>:8889/ca
```

Find your machine's LAN IP (`ipconfig getifaddr en0` on Mac, `ip addr`
on Linux, `ipconfig` on Windows) — you'll need it for both the proxy
setting and the CA download, since "127.0.0.1" only means "this machine"
to itself, not to your phone.

## Phone-only, no PC at all

**Android: yes, this works.** Termux gives Android a real Linux
userland that can run Node as a background server, so the phone can run
`sys-proxy` *on itself* — no computer anywhere in the loop. See
`termux/setup.sh` below.

**iOS: not possible without a separate device, period.** This isn't a
gap in this project — it's a hard platform wall. iOS sandboxes every
app individually and gives none of them the ability to run a
background server process that the OS can route other apps' traffic
to. The technically-correct way Apple supports this (`NEAppProxyProvider`
/ `NEPacketTunnelProvider`, used by every legitimate iOS packet-capture
app) requires a real native Swift app, a paid Apple Developer account,
Apple's network-extension entitlement approval, and distribution via
Xcode/TestFlight/the App Store — it cannot be a webpage, a script, or
anything installed by visiting a URL or running a shell command. If you
only have an iPhone, you need *some* second device (even an old Android
phone running Termux) to act as the proxy host.

### Android / Termux setup (phone-only)

1. Install **Termux from F-Droid** (not the Play Store — that build is
   outdated and package installs frequently fail on it).
2. Get this `sys-proxy` folder onto the phone (e.g. `pkg install git`
   then clone it, or use Termux's file sharing to copy the folder over).
3. From inside the `sys-proxy` folder in Termux:
   ```bash
   chmod +x termux/setup.sh
   ./termux/setup.sh
   ```
   This installs Node, installs dependencies, generates the CA, and
   prints your phone's own Wi-Fi IP plus the exact next steps.
4. Start the proxy: `npm start`, or for it to survive backgrounding the
   Termux app, use `./termux/keep-alive.sh` (runs it in `tmux` with a
   wake-lock — see the caveats inside that script; Android's battery
   managers can still kill it on some OEM skins unless you also set
   Termux to "Unrestricted" battery usage manually).
5. Install the CA **on this same phone**: open a browser and visit
   `http://127.0.0.1:8889/ca`, then follow the Android steps below.
6. Set the phone's own Wi-Fi proxy to point at itself: **Settings →
   Wi-Fi → long-press your network → Modify network → Advanced → Proxy
   → Manual**, Server = the phone's own Wi-Fi IP (from step 3's output,
   not `127.0.0.1` — Android's proxy setting needs a real address even
   when it's the same device), Port = `8888`.
7. Open `hook.html` (in a browser on the phone, or anywhere that can
   reach the phone's IP) and connect to `ws://<phone-IP>:8889`.

## Installing the CA — iPhone

1. On the iPhone, open Safari and go to `http://<your-computer-LAN-IP>:8889/ca`
2. iOS will prompt "This website is trying to download a configuration
   profile" — allow it.
3. Go to **Settings → General → VPN & Device Management**, tap the
   downloaded profile, then **Install** (you'll need your passcode).
4. **Critical extra step iOS requires:** go to **Settings → General →
   About → Certificate Trust Settings**, and toggle full trust **on**
   for the cert you just installed. Without this step iOS will install
   the profile but still reject the certificate for TLS, and HTTPS
   sites will fail to load.
5. Go to **Settings → Wi-Fi → (i) next to your network → Configure
   Proxy → Manual**, set Server to your computer's LAN IP, Port `8888`.

## Installing the CA — Desktop (macOS)

1. Download the cert: `curl http://127.0.0.1:8889/ca -o sys-proxy-ca.crt`
2. Open it (double-click) — it opens in Keychain Access.
3. Find it in the "login" or "System" keychain, double-click it, expand
   **Trust**, and set **"When using this certificate"** to **Always Trust**.
4. Set your Wi-Fi/network proxy settings (System Settings → Network →
   your connection → Details → Proxies) to `127.0.0.1:8888` for both
   HTTP and HTTPS (Secure Web Proxy).

## Installing the CA — Desktop (Windows)

1. Download the cert from `http://127.0.0.1:8889/ca`, rename to `.crt`
   if needed.
2. Double-click it → **Install Certificate** → **Local Machine** →
   place it in **Trusted Root Certification Authorities**.
3. Set proxy in Settings → Network & Internet → Proxy → Manual setup,
   address `127.0.0.1`, port `8888`.

## Installing the CA — Desktop (Linux / Firefox)

Firefox keeps its own cert store separate from the OS:
**Settings → Privacy & Security → Certificates → View Certificates →
Authorities → Import**, select the downloaded `ca.cert.pem`, and check
"Trust this CA to identify websites."

For Chrome on Linux, import into the NSS database (`certutil`) or via
**Settings → Privacy and Security → Security → Manage certificates**.

## Connecting px://hook

1. Open `hook.html` in a browser (on the same machine running the
   proxy, or any machine that can reach it).
2. Click the gear icon (settings) in the header.
3. Under **MITM Proxy Link**, enter `ws://<proxy-host>:8889` (use
   `127.0.0.1` if running on the same machine you're browsing
   `hook.html` from) and click **Connect**.
4. Browse on your phone/desktop (with the proxy + CA configured as
   above) — every request will appear live in px://hook's request list,
   with real headers, real methods, decrypted HTTPS bodies, and you can
   send anything to Repeater/Intruder exactly like before.

## Limitations / honesty check

- **WebSocket/raw TCP traffic inside CONNECT tunnels that isn't HTTP**
  (e.g. some app-specific protocols) isn't parsed — only HTTP/HTTPS
  request/response pairs are captured.
- **Certificate pinning**: apps that pin certificates (rather than
  trusting the OS root store) will refuse to connect through this proxy
  no matter what — this is true of Burp too. This mostly affects some
  native apps, not regular browser traffic.
- **HTTP/2 inside the tunnel** is not specifically negotiated by the
  inner server (it speaks HTTP/1.1 to the client over the decrypted
  TLS socket) — browsers will fall back to HTTP/1.1 for proxied
  connections, which is normal and matches what most simple MITM
  proxies do.
- The in-memory history is capped (2000 entries) and clears on
  restart — there's no persistent storage yet.

## Files

```
sys-proxy/
  package.json
  src/
    gen-ca.js          one-time root CA generation
    ca-authority.js     mints + caches per-hostname leaf certs at runtime
    server.js            the proxy + CONNECT/TLS termination + capture + API/WS
  termux/
    setup.sh              phone-only bootstrap: installs Node, deps, generates CA
    keep-alive.sh          runs the proxy in tmux with a wake-lock for background survival
  certs/                 generated CA (gitignore this in any repo you push)
```
