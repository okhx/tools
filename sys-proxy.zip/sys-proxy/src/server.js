// sys-proxy: local forward MITM proxy.
//
// Point a device's HTTP/HTTPS proxy settings at this server's host:port.
// For HTTPS to be readable, the device must trust the CA from /ca (see README).
//
// Every intercepted request/response is captured in full (method, url,
// headers, body, status, response headers/body, timing) and broadcast over
// WebSocket to any connected UI (px://hook), plus kept in an in-memory ring
// buffer served over HTTP for late-joining clients.

import http from 'http';
import https from 'https';
import net from 'net';
import tls from 'tls';
import { URL } from 'url';
import { WebSocketServer } from 'ws';
import { getCaCertPem, getLeafCertForHost } from './ca-authority.js';

const PROXY_PORT = parseInt(process.env.SYS_PROXY_PORT || '8888', 10);
const MAX_BODY_CAPTURE = 2 * 1024 * 1024; // 2MB cap per body, like Burp's display cap
const HISTORY_LIMIT = 2000;

const history = [];
const wsClients = new Set();
let nextId = 1;

function broadcast(entry) {
  const msg = JSON.stringify({ type: 'capture', entry });
  for (const ws of wsClients) {
    if (ws.readyState === ws.OPEN) ws.send(msg);
  }
}

function pushHistory(entry) {
  history.push(entry);
  if (history.length > HISTORY_LIMIT) history.shift();
  broadcast(entry);
}

function capBuffer(buf) {
  if (buf.length <= MAX_BODY_CAPTURE) return buf;
  return Buffer.concat([buf.subarray(0, MAX_BODY_CAPTURE), Buffer.from(`\n...[truncated, captured ${MAX_BODY_CAPTURE} of ${buf.length} bytes]`)]);
}

function bodyToDisplayString(buf, headers) {
  const ct = (headers['content-type'] || '').toLowerCase();
  const isBinary = /image\/|video\/|audio\/|font\/|application\/octet-stream|application\/pdf|application\/zip/.test(ct);
  if (isBinary) return `[binary ${ct || 'data'}, ${buf.length} bytes]`;
  try {
    return capBuffer(buf).toString('utf8');
  } catch (e) {
    return `[unreadable body, ${buf.length} bytes]`;
  }
}

// ---------- request/response capture core ----------

function captureExchange({ method, fullUrl, reqHeaders, reqBodyChunks, scheme }) {
  const id = nextId++;
  const startedAt = Date.now();
  const reqBodyBuf = Buffer.concat(reqBodyChunks);
  const entry = {
    id,
    method,
    url: fullUrl,
    scheme,
    headers: reqHeaders,
    body: bodyToDisplayString(reqBodyBuf, reqHeaders),
    bodySize: reqBodyBuf.length,
    status: null,
    statusText: '',
    responseHeaders: {},
    responseBody: '',
    responseSize: 0,
    startedAt,
    duration: null,
    requestType: 'proxy',
    error: false
  };
  return entry;
}

function finalizeEntry(entry, { status, statusText, responseHeaders, responseBodyBuf, error, errorMessage }) {
  entry.duration = (Date.now() - entry.startedAt) + 'ms';
  if (error) {
    entry.status = 0;
    entry.statusText = errorMessage || 'Proxy Error';
    entry.error = true;
    entry.responseBody = errorMessage || '';
    pushHistory(entry);
    return;
  }
  entry.status = status;
  entry.statusText = statusText || '';
  entry.responseHeaders = responseHeaders || {};
  entry.responseBody = bodyToDisplayString(responseBodyBuf || Buffer.alloc(0), responseHeaders || {});
  entry.responseSize = responseBodyBuf ? responseBodyBuf.length : 0;
  pushHistory(entry);
}

function flatHeaders(rawHeaders) {
  // Node gives headers already as a plain object (lowercased keys) for
  // http.IncomingMessage; this just guards against array values (set-cookie etc).
  const out = {};
  for (const [k, v] of Object.entries(rawHeaders || {})) {
    out[k] = Array.isArray(v) ? v.join(', ') : v;
  }
  return out;
}

// ---------- plain HTTP proxying (GET http://host/path HTTP/1.1 style) ----------

const proxyServer = http.createServer((clientReq, clientRes) => {
  let targetUrl;
  try {
    targetUrl = new URL(clientReq.url);
  } catch (e) {
    clientRes.writeHead(400);
    clientRes.end('Bad request');
    return;
  }

  const reqBodyChunks = [];
  clientReq.on('data', (c) => reqBodyChunks.push(c));

  clientReq.on('end', () => {
    const reqHeaders = flatHeaders(clientReq.headers);
    const entry = captureExchange({
      method: clientReq.method,
      fullUrl: targetUrl.href,
      reqHeaders,
      reqBodyChunks,
      scheme: 'http'
    });

    const outHeaders = { ...reqHeaders };
    delete outHeaders['proxy-connection'];
    delete outHeaders['proxy-authorization'];

    const upstreamReq = http.request({
      hostname: targetUrl.hostname,
      port: targetUrl.port || 80,
      path: targetUrl.pathname + targetUrl.search,
      method: clientReq.method,
      headers: outHeaders
    }, (upstreamRes) => {
      const resChunks = [];
      upstreamRes.on('data', (c) => resChunks.push(c));
      upstreamRes.on('end', () => {
        finalizeEntry(entry, {
          status: upstreamRes.statusCode,
          statusText: upstreamRes.statusMessage,
          responseHeaders: flatHeaders(upstreamRes.headers),
          responseBodyBuf: Buffer.concat(resChunks)
        });
      });
      clientRes.writeHead(upstreamRes.statusCode, upstreamRes.headers);
      upstreamRes.pipe(clientRes);
    });

    upstreamReq.on('error', (err) => {
      finalizeEntry(entry, { error: true, errorMessage: err.message });
      if (!clientRes.headersSent) clientRes.writeHead(502);
      clientRes.end('Upstream error: ' + err.message);
    });

    if (reqBodyChunks.length) upstreamReq.write(Buffer.concat(reqBodyChunks));
    upstreamReq.end();
  });
});

// ---------- CONNECT handling: TLS termination per host ----------

proxyServer.on('connect', (req, clientSocket, head) => {
  const [hostname, portStr] = req.url.split(':');
  const port = parseInt(portStr || '443', 10);

  clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');

  // mint (or reuse cached) leaf cert for this hostname, then speak TLS to
  // the client using it - this is the actual interception point.
  let leaf;
  try {
    leaf = getLeafCertForHost(hostname);
  } catch (e) {
    clientSocket.destroy();
    return;
  }

  const tlsSocket = new tls.TLSSocket(clientSocket, {
    isServer: true,
    key: leaf.keyPem,
    cert: leaf.certPem,
    SNICallback: (servername, cb) => {
      try {
        const l = getLeafCertForHost(servername || hostname);
        cb(null, tls.createSecureContext({ key: l.keyPem, cert: l.certPem }));
      } catch (e) {
        cb(e);
      }
    }
  });

  // Each HTTPS request inside this tunnel is handled as its own HTTP
  // exchange over the now-decrypted TLS socket.
  const innerServer = http.createServer((innerReq, innerRes) => {
    const reqBodyChunks = [];
    innerReq.on('data', (c) => reqBodyChunks.push(c));
    innerReq.on('end', () => {
      const reqHeaders = flatHeaders(innerReq.headers);
      const fullUrl = `https://${hostname}${innerReq.url}`;
      const entry = captureExchange({
        method: innerReq.method,
        fullUrl,
        reqHeaders,
        reqBodyChunks,
        scheme: 'https'
      });

      const outHeaders = { ...reqHeaders };
      delete outHeaders['proxy-connection'];

      const upstreamReq = https.request({
        hostname,
        port,
        path: innerReq.url,
        method: innerReq.method,
        headers: outHeaders,
        rejectUnauthorized: true
      }, (upstreamRes) => {
        const resChunks = [];
        upstreamRes.on('data', (c) => resChunks.push(c));
        upstreamRes.on('end', () => {
          finalizeEntry(entry, {
            status: upstreamRes.statusCode,
            statusText: upstreamRes.statusMessage,
            responseHeaders: flatHeaders(upstreamRes.headers),
            responseBodyBuf: Buffer.concat(resChunks)
          });
        });
        innerRes.writeHead(upstreamRes.statusCode, upstreamRes.headers);
        upstreamRes.pipe(innerRes);
      });

      upstreamReq.on('error', (err) => {
        finalizeEntry(entry, { error: true, errorMessage: err.message });
        if (!innerRes.headersSent) innerRes.writeHead(502);
        innerRes.end('Upstream error: ' + err.message);
      });

      if (reqBodyChunks.length) upstreamReq.write(Buffer.concat(reqBodyChunks));
      upstreamReq.end();
    });
  });

  innerServer.on('error', () => { try { tlsSocket.destroy(); } catch (e) {} });
  tlsSocket.on('error', () => { try { innerServer.close(); } catch (e) {} });
  innerServer.emit('connection', tlsSocket);
});

// ---------- companion HTTP API (CA download, history, WS) on a separate port ----------

const API_PORT = parseInt(process.env.SYS_PROXY_API_PORT || '8889', 10);

const apiServer = http.createServer((req, res) => {
  if (req.url === '/ca' || req.url === '/ca.pem' || req.url === '/ca.crt') {
    res.writeHead(200, {
      'Content-Type': 'application/x-x509-ca-cert',
      'Content-Disposition': 'attachment; filename="sys-proxy-ca.crt"'
    });
    res.end(getCaCertPem());
    return;
  }
  if (req.url === '/history') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify(history));
    return;
  }
  if (req.url === '/clear' && req.method === 'POST') {
    history.length = 0;
    res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }
  res.writeHead(404);
  res.end('Not found. Endpoints: /ca, /history, /clear (POST). WebSocket on this same port.');
});

const wss = new WebSocketServer({ server: apiServer });
wss.on('connection', (ws) => {
  wsClients.add(ws);
  ws.send(JSON.stringify({ type: 'history', entries: history }));
  ws.on('close', () => wsClients.delete(ws));
});

proxyServer.listen(PROXY_PORT, () => {
  console.log(`[sys-proxy] MITM proxy listening on 0.0.0.0:${PROXY_PORT}`);
  console.log(`[sys-proxy] Point device proxy settings here.`);
});

apiServer.listen(API_PORT, () => {
  console.log(`[sys-proxy] API + WebSocket on 0.0.0.0:${API_PORT}`);
  console.log(`[sys-proxy] Install CA cert from: http://<this-host>:${API_PORT}/ca`);
});
