// Mints per-hostname leaf certificates signed by the local root CA,
// on demand, with an in-memory cache. This is what lets the proxy
// terminate TLS for *any* hostname the client connects to, the same
// way Burp/mitmproxy generate certs per-host at interception time.

import forge from 'node-forge';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CERTS_DIR = path.join(__dirname, '..', 'certs');

const caKeyPem = fs.readFileSync(path.join(CERTS_DIR, 'ca.key.pem'), 'utf8');
const caCertPem = fs.readFileSync(path.join(CERTS_DIR, 'ca.cert.pem'), 'utf8');
const caKey = forge.pki.privateKeyFromPem(caKeyPem);
const caCert = forge.pki.certificateFromPem(caCertPem);

const leafCache = new Map(); // hostname -> { keyPem, certPem }

export function getCaCertPem() {
  return caCertPem;
}

export function getLeafCertForHost(hostname) {
  if (leafCache.has(hostname)) return leafCache.get(hostname);

  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();

  cert.publicKey = keys.publicKey;
  cert.serialNumber = '01' + forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date();
  cert.validity.notBefore.setDate(cert.validity.notBefore.getDate() - 1);
  cert.validity.notAfter = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notAfter.getFullYear() + 2);

  cert.setSubject([{ name: 'commonName', value: hostname }]);
  cert.setIssuer(caCert.subject.attributes);

  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(hostname);
  cert.setExtensions([
    { name: 'basicConstraints', cA: false },
    { name: 'keyUsage', digitalSignature: true, keyEncipherment: true, critical: true },
    { name: 'extKeyUsage', serverAuth: true },
    {
      name: 'subjectAltName',
      altNames: [isIp ? { type: 7, ip: hostname } : { type: 2, value: hostname }]
    }
  ]);

  cert.sign(caKey, forge.md.sha256.create());

  const result = {
    keyPem: forge.pki.privateKeyToPem(keys.privateKey),
    certPem: forge.pki.certificateToPem(cert)
  };
  leafCache.set(hostname, result);
  return result;
}
