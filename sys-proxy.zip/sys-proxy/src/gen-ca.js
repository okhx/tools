// Generates a local root CA (key + cert) used to sign per-host leaf certs
// at runtime, so the proxy can terminate TLS and see decrypted traffic.
// This is the exact same trust model Burp / mitmproxy / Charles use:
// you install THIS cert (and only this cert) as a trusted root on the
// devices you intentionally route through this proxy.
//
// Run once: `npm run gen-ca`
// Output:  certs/ca.key.pem, certs/ca.cert.pem

import forge from 'node-forge';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CERTS_DIR = path.join(__dirname, '..', 'certs');

function generateCA() {
  const keys = forge.pki.rsa.generateKeyPair(2048);
  const cert = forge.pki.createCertificate();

  cert.publicKey = keys.publicKey;
  cert.serialNumber = '01' + forge.util.bytesToHex(forge.random.getBytesSync(8));
  cert.validity.notBefore = new Date();
  cert.validity.notBefore.setDate(cert.validity.notBefore.getDate() - 1);
  cert.validity.notAfter = new Date();
  cert.validity.notAfter.setFullYear(cert.validity.notAfter.getFullYear() + 10);

  const attrs = [
    { name: 'commonName', value: 'sys://shell Local MITM Root' },
    { name: 'organizationName', value: 'sys-proxy local-only CA' },
    { shortName: 'OU', value: 'do-not-trust-outside-this-machine' }
  ];
  cert.setSubject(attrs);
  cert.setIssuer(attrs); // self-signed root

  cert.setExtensions([
    { name: 'basicConstraints', cA: true, critical: true },
    { name: 'keyUsage', keyCertSign: true, digitalSignature: true, cRLSign: true, critical: true },
    { name: 'subjectKeyIdentifier' }
  ]);

  cert.sign(keys.privateKey, forge.md.sha256.create());

  if (!fs.existsSync(CERTS_DIR)) fs.mkdirSync(CERTS_DIR, { recursive: true });

  fs.writeFileSync(path.join(CERTS_DIR, 'ca.key.pem'), forge.pki.privateKeyToPem(keys.privateKey));
  fs.writeFileSync(path.join(CERTS_DIR, 'ca.cert.pem'), forge.pki.certificateToPem(cert));

  console.log('Generated local root CA:');
  console.log('  ' + path.join(CERTS_DIR, 'ca.cert.pem') + '  <- install this on your devices');
  console.log('  ' + path.join(CERTS_DIR, 'ca.key.pem') + '   <- keep this secret, never share/install it');
  console.log('');
  console.log('Next: start the proxy, then visit http://<proxy-host>:8888/ca on the');
  console.log('device you want to intercept and follow the install prompt.');
}

const existingKey = path.join(CERTS_DIR, 'ca.key.pem');
const existingCert = path.join(CERTS_DIR, 'ca.cert.pem');
if (fs.existsSync(existingKey) && fs.existsSync(existingCert)) {
  console.log('CA already exists at ' + CERTS_DIR + ' - delete those files first if you want to regenerate.');
} else {
  generateCA();
}
